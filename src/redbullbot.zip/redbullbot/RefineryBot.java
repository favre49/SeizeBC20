package redbullbot;
import battlecode.common.*;

/**
 * Built by: Miners
 * Cost: 200
 * Health: 15
 * Sensor Radius: 24
 * Produces: Soup
 *
 * Dirty energy. Creates pollution. Also every turn it refines it creates
 * a pollution effect that lasts a turn.
 */
public strictfp class RefineryBot extends Globals
{
	public static void run(RobotController rc)
	{
		
	}
}