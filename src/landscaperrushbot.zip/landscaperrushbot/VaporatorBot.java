package landscaperrushbot;

import battlecode.common.*;

/**
 * BUilt by: Miners
 * Cost: 1000 lol
 * Health: 15
 * Sensor radius: 24
 * Produces: Soup
 *
 * Clean energy, actually removes pollution.
 */
public strictfp class VaporatorBot extends Globals
{
	public static void run(RobotController rc)
	{
		
	}
}